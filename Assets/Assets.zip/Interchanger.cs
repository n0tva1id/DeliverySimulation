﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interchanger : MonoBehaviour
{
    public int flag=1;//一为下单点 二为顾客点
    public int rest_x,rest_y;
    public int Index=0;

}
